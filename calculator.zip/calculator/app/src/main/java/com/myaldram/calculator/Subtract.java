package com.myaldram.calculator;

public class Subtract {
}
