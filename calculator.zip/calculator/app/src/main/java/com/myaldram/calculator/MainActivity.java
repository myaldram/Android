package com.myaldram.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button optBtn=findViewById(R.id.button);
        optBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Spinner options=findViewById(R.id.option);
                EditText num1=findViewById(R.id.num1);
                EditText num2=findViewById(R.id.num2);
                TextView result=findViewById(R.id.result);

                String selection=options.getSelectedItem().toString();
                if(selection.trim().equals("+")){
                    int res=Integer.parseInt(num1.getText().toString())+Integer.parseInt(num2.getText().toString());
                    result.setText(Integer.toString(res));
                }
                else if(selection.trim().equals("-")){
                    int res=Integer.parseInt(num1.getText().toString())-Integer.parseInt(num2.getText().toString());
                    result.setText(Integer.toString(res));
                }
                else if(selection.trim().equals("*")){
                    int res=Integer.parseInt(num1.getText().toString())*Integer.parseInt(num2.getText().toString());
                    result.setText(Integer.toString(res));
                }
                else if(selection.trim().equals("/")){
                    if(num2.getText().toString()!="0") {
                        int res=Integer.parseInt(num1.getText().toString())/Integer.parseInt(num2.getText().toString());
                        result.setText(Integer.toString(res));
                    }
                    else{
                        result.setText("Division by zero is not possible");
                    }
                }
            }
        });
    }
}