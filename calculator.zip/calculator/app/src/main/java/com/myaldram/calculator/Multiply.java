package com.myaldram.calculator;

public class Multiply {
}
